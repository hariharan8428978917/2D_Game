package Game1;

import javax.swing.JPanel;


import entity.Player;
import tile.TileManager;

import java.awt.*;

public class GamePanel extends JPanel implements Runnable
{
	// SCREEN SETTING
	final int originalTileSize = 16;  // 16 *16 size
	final int scale = 3 ;
	
	public final int tileSize = originalTileSize * scale;   //48*48 size
	public final int maxScreenCol=16;
	public final int maxScreenRow=12;
	public final int screenWidth = tileSize * maxScreenCol;  //768 PIX
	public final int screenHeight = tileSize * maxScreenRow; // 576
	
	
	// WORLD MAP SETTINGS
	public final int maxWorldCol = 50;
	public final int maxWorldRow = 50;
	public final int maxWidth = tileSize * maxWorldCol ;
	public final int maxHeight = tileSize * maxWorldRow ;

	
	
	Thread gameThread;
	keyHandler keyH = new keyHandler() ;
	public Player player = new Player(this,keyH);
	TileManager tileManger = new TileManager(this);
	
	// set player default position
	
	int playerX=100;
	int playerY= 100;
	int playerSpeed=4;
	int FPS = 60;
	
	
	public GamePanel()
	{
		this.setPreferredSize(new Dimension(screenWidth,screenHeight));  // set the jpanel size
		this.setBackground(Color.black);
		this.setDoubleBuffered(true);    			// set enabling this can improve games's rendering performance
		this.addKeyListener(keyH);   // add key listener 
		this.setFocusable(true);	// with this ,this GamePanel can be "focused" to recevie key input		
	}
	public void startGameThread()
	{
		gameThread = new Thread(this);  // it create a thread for that class -Game panel class 
		gameThread.start();  // it automaticallly call run method this method create a game loop
	}


	public void run() {
		
		/* one way of slepping
		
		double drawInterval = 1000000000/FPS;   // 0.166 seconds 
		double nextDrawTime = System.nanoTime()+drawInterval; 
		
		while(gameThread != null )
		{
			

			// 1. UPDATE ---  update information from charcteryies
			
			update();
			
			
			
			// 2. DRAW  ----- draw the potioon fo charcters
			repaint();
			
			
			
			
			
			try {
				
				// sleep the remaining time
				double remainingTime =  nextDrawTime-System.nanoTime();
				
				remainingTime = remainingTime/100000  ;   // convert nano to milli sec  
				
				if ( remainingTime< 0)
					remainingTime=0;
				
				
				nextDrawTime  = nextDrawTime+ drawInterval;
				
				gameThread.sleep((long) remainingTime);
			} 
			catch (InterruptedException e) {
				
				e.printStackTrace();
			}
		}    
		*/
		
		// another way 
		
		double drawInterval = 1000000000/FPS;
		double delta =0;
		long lastTime = System.nanoTime();
		long currentTime;
		long timer =0;
		long drawCount=0;
		
		while( gameThread != null)
		{
			currentTime = System.nanoTime();
			delta += (currentTime -lastTime ) / drawInterval;
			// HOW MUCH TIME IS PASS
			
			timer += (currentTime -lastTime );
			lastTime = currentTime;
			
			if(delta >=1)
			{
				update();
				repaint();
				delta--;
				drawCount++;
			}
			if( timer >= 1000000000)
			{
				System.out.println("FPS" + drawCount);
				drawCount = 0;
				timer=0;
			}
		}
		
	}
	public void update()
	{
		
		player.update();
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);  // a class has a many function to draw a objexts on the screen when ever we use graphic it need to add japanel
		
		Graphics2D g2 = (Graphics2D)g;
		
		tileManger.draw(g2);
		
		player.draw(g2);
		
		g2.dispose();   // dispose the graphic context and relase any syste resources that it is using
		
		
		
		
		
		
		
	}
	
	
	
}
