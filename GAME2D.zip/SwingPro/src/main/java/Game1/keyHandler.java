package Game1;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

// it for jeyboard handle

public class keyHandler implements KeyListener  // it is interface for receving keyboard status
{
	
	public boolean upPressed,downPressed,leftPressed,rightPressed;
	
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
		int code = e.getKeyCode();    // returns the integer keycode associated with the key in this  event  example 8 - backspace ,9-tab,
									// 10-enter 12 - clear, 16-shift 17-ctrl  18 - alt asiic value for other letters
		
		if( code == KeyEvent.VK_W)
		{
			upPressed=true;
		
		}
		if( code == KeyEvent.VK_S)
		{
			downPressed=true;
		}
		if( code == KeyEvent.VK_D)
		{
			rightPressed=true;
		}
		if( code == KeyEvent.VK_A)
		{
			leftPressed=true;
		}
		
	}

	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
		int code = e.getKeyCode(); 
		
		if( code == KeyEvent.VK_W)
		{
			upPressed=false;
		}
		if( code == KeyEvent.VK_S)
		{
			downPressed=false;
		}
		if( code == KeyEvent.VK_A)
		{
			leftPressed=false;
		}
		if( code == KeyEvent.VK_D)
		{
			rightPressed=false;
		}
		
	}

	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
