package tile;

import java.io.BufferedReader;


import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import Game1.GamePanel;

public class TileManager {
	
	GamePanel gp;
	Tile[] tile;
	public int mapTileNum[][];
	
	public TileManager(GamePanel gp)
	{
		this.gp = gp;
		
		tile = new Tile[10];
		
		 mapTileNum = new int[gp.maxWorldCol][gp.maxWorldRow];
		
		getImage();
		
		loadMap();
		
		
		
	}
	public void getImage()
	{
		try
		{
			tile[0] = new Tile();		// grass image
			tile[0].image = ImageIO.read(getClass().getResourceAsStream("/tils/grass.png"));
			
			// wall image
			tile[1] = new Tile();		// wall image
			tile[1].image = ImageIO.read(getClass().getResourceAsStream("/tils/wall.png"));
			
			// gwater image
			tile[2] = new Tile();		// water image
			tile[2].image = ImageIO.read(getClass().getResourceAsStream("/tils/water.png"));
			
			// wall image
			tile[3] = new Tile();		// earth image
			tile[3].image = ImageIO.read(getClass().getResourceAsStream("/tils/earth.png"));
			
			// wall image
			tile[4] = new Tile();		//tree image
			tile[4].image = ImageIO.read(getClass().getResourceAsStream("/tils/tree.png"));
			
			// wall image
			tile[5] = new Tile();		// wall image
			tile[5].image = ImageIO.read(getClass().getResourceAsStream("/tils/sand.png"));
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public void loadMap()
	{
		try {
			InputStream  is = getClass().getResourceAsStream("/map/world01.txt");
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col =0;
			int row=0;
			
			while( col< gp.maxWorldCol && row < gp.maxWorldRow)
			{
				String line = br.readLine();
				
				while( col< gp.maxWorldCol)
				{
					String number[] = line.split(" ");
					
					int num  = Integer.parseInt(number[col]);
					
					mapTileNum[col][row]= num;
					col++;
				}
				if(col == gp.maxWorldCol )
				{
					col=0;
					row++;
				}
			}
			br.close();
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void draw(Graphics2D g)
	{
		// AUTOMATIC TILE  DRAWING PROCESS
		int worldCol =0;
		int worldRow =0;
	
		
		while(worldCol < gp.maxWorldCol  && worldRow < gp.maxWorldRow)
		{
			
			try {
			// SETTING THE CENTER THE MAPS
			int tileNum =  mapTileNum[worldCol][worldRow];
			
			int worldX = worldCol * gp.tileSize;
			int worldY = worldRow * gp.tileSize;
			int screenX = worldX -   gp.player.worldX  + gp.player.screenX;
			int screenY  = worldY -  gp.player.worldY  + gp.player.screenY;
			
			
			
			g.drawImage(tile[tileNum].image,  screenX , screenY ,gp.tileSize,gp.tileSize,null);
			worldCol++;
			
			if( worldCol == gp.maxWorldCol)
			{
				worldCol=0;
				
				worldRow++;
				
			
				
			}
			}
			catch( Exception e)
			{
				System.out.println("error aquried");
				e.printStackTrace();
			}
		}
		
		
		
	}
	

}
